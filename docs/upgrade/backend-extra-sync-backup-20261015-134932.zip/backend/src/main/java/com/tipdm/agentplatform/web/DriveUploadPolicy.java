package com.tipdm.agentplatform.web;

import java.util.Locale;
import java.util.Set;

/**
 * drive 文件上传策略：大小上限与扩展名白名单。
 *
 * <p>独立成类而非复用 {@code AttachmentController} 的私有常量——
 * 会话附件与资料库文件是两条业务线：前者随会话销毁、后者长期留存，
 * 上限可以不同。但**扩展名口径保持一致**，避免用户困惑
 * 「同一个文件在对话里能传、在资料库传不了」。</p>
 */
public final class DriveUploadPolicy {

    private DriveUploadPolicy() {
    }

    /**
     * 单文件上限。
     *
     * <p>⚠️ 必须 ≤ Spring 的全局 multipart 限制（{@code spring.servlet.multipart.max-file-size}，
     * 当前 25MB），否则超限会在进入 Controller 前被容器抛
     * {@code MaxUploadSizeExceededException}，本类的检查永远走不到，
     * 且前端拿到的是 500/通用错误而非这里的可读提示。</p>
     */
    public static final long MAX_BYTES = 25L * 1024 * 1024;

    /** 允许的扩展名；与 AttachmentController.ALLOWED_EXTENSIONS 同口径。 */
    private static final Set<String> ALLOWED = Set.of(
            "txt", "md", "markdown", "json", "csv", "tsv",
            "py", "java", "js", "ts", "tsx", "jsx", "html", "css", "sql", "xml", "yaml", "yml", "sh",
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx",
            "png", "jpg", "jpeg");

    /** 扩展名是否在白名单内；无扩展名或取不到扩展名时拒绝。 */
    public static boolean isAllowed(String filename) {
        if (filename == null || filename.isBlank()) {
            return false;
        }
        int dot = filename.lastIndexOf('.');
        if (dot < 0 || dot == filename.length() - 1) {
            return false;
        }
        String ext = filename.substring(dot + 1).toLowerCase(Locale.ROOT);
        return ALLOWED.contains(ext);
    }
}
