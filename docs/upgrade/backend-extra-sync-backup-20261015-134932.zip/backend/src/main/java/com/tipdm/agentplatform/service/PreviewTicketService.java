package com.tipdm.agentplatform.service;

import com.tipdm.agentplatform.config.AuthProperties;
import com.tipdm.agentplatform.config.DocumentPreviewProperties;
import com.tipdm.agentplatform.util.RedisKeyConstants;
import com.tipdm.agentplatform.util.RedisUtils;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * 预览文件回拉票据：让<b>预览服务</b>（TipDM-FV）能取到平台上的文件字节。
 *
 * <p><strong>为什么需要它</strong>：TipDM-FV 的接口只接受一个 {@code url} 参数，
 * 由它自己发起下载。而平台的文件在本地磁盘上、且不暴露给外部，
 * 所以必须提供一个「凭票据放行、只读单个文件」的窄门给预览服务回拉。
 * 与 {@link DownloadTicketService} 是同一思路、但<b>面向不同的调用方</b>：
 * 后者给浏览器（原生下载链接挂不了 Authorization 头），本票据给服务端程序。</p>
 *
 * <p><strong>票据是降权而非提权</strong>：权限严格小于 access token——单次、极短时效、
 * 绑定到<b>具体空间+具体相对路径</b>。拿到票据只能读那一个文件，
 * 且票据本身不含用户身份语义（回拉端点由预览服务匿名调用，无从判权，
 * 因此权限判定必须在此之前完成，见 {@code DocumentPreviewTool}）。</p>
 *
 * <p><strong>真单次</strong>：同 {@code DownloadTicketService}——用 Redis SETNX 记录
 * 已消费的 jti，并发重放只有一个能过；Redis 不可用时<b>拒绝放行</b>（fail-close）。</p>
 */
@Service
public class PreviewTicketService {

    private static final Logger log = LoggerFactory.getLogger(PreviewTicketService.class);

    /**票据 claim 里的 type 值。刻意区别于 access/download：JwtAuthFilter 只接受 access。 */
    public static final String TICKET_TYPE = "preview";

    private static final String CLAIM_SPACE_ID = "spc";
    private static final String CLAIM_REL_PATH = "pth";
    private static final String CLAIM_FILE_NAME = "fnm";

    private final SecretKey signingKey;
    private final RedisUtils redisUtils;
    private final Duration ttl;

    public PreviewTicketService(AuthProperties authProperties,
                                RedisUtils redisUtils,
                                DocumentPreviewProperties properties) {
        this.signingKey = Keys.hmacShaKeyFor(
                authProperties.getJwtSecretKey().getBytes(StandardCharsets.UTF_8));
        this.redisUtils = redisUtils;
        this.ttl = properties.ticketTtl();
    }

    /**
     * 签发一张绑定到具体文件路径的回拉票据。
     *
     * @param spaceId      资料库空间 ID
     * @param relativePath 空间内的相对路径（{@code LibraryBlobStore} 口径）
     * @param fileName     原始文件名（票据载荷，回拉时按它还原带后缀的文件名）
     */
    public String issue(UUID spaceId, String relativePath, String fileName) {
        Instant now = Instant.now();
        String jti = UUID.randomUUID().toString();
        String token = Jwts.builder()
                .subject(jti)
                .id(jti)
                .issuer(JwtService.ISSUER)
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plus(ttl)))
                .claim("type", TICKET_TYPE)
                .claim(CLAIM_SPACE_ID, spaceId.toString())
                .claim(CLAIM_REL_PATH, relativePath)
                .claim(CLAIM_FILE_NAME, fileName == null ? "" : fileName)
                .signWith(signingKey)
                .compact();
        log.info("签发预览回拉票据 space={} path={} file={} jti={} ttl={}s",
                spaceId, relativePath, fileName, jti, ttl.toSeconds());
        return token;
    }

    /**
     * 校验并<b>原子消费</b>一张票据：验签 → 校验类型/时效 → SETNX 标记已用。
     *
     * <p>⚠️ <b>不重复使用</b>：TipDM-FV 拿到 {@code url} 后只会回拉一次，
     * 若它内部重试需要重新签发（上层在调预览接口时重新 issue 即可）。</p>
     *
     * @param token 待核销的票据
     * @return 票据载荷；无效/过期/已使用/Redis 不可用均返回 {@link Optional#empty()}
     */
    public Optional<Ticket> consume(String token) {
        Claims claims;
        try {
            claims = Jwts.parser()
                    .verifyWith(signingKey)
                    .requireIssuer(JwtService.ISSUER)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
        } catch (JwtException | IllegalArgumentException e) {
            log.warn("预览票据验签失败: {}", e.getMessage());
            return Optional.empty();
        }

        if (!TICKET_TYPE.equals(claims.get("type", String.class))) {
            return Optional.empty();
        }
        Date exp = claims.getExpiration();
        if (exp == null || !exp.toInstant().isAfter(Instant.now())) {
            return Optional.empty();
        }

        String spaceId = claims.get(CLAIM_SPACE_ID, String.class);
        String relPath = claims.get(CLAIM_REL_PATH, String.class);
        if (spaceId == null || relPath == null || relPath.isBlank()) {
            return Optional.empty();
        }

        // 真单次：原子写入「已消费」标记，并发下只有一个能成功
        String jti = claims.getId();
        if (jti == null) {
            return Optional.empty();
        }
        String key = RedisKeyConstants.previewTicketUsedKey(jti);
        try {
            Boolean fresh = redisUtils.getRedisTemplate()
                    .opsForValue()
                    .setIfAbsent(key, spaceId);
            if (!Boolean.TRUE.equals(fresh)) {
                log.warn("预览票据重复使用（已消费）: jti={}", jti);
                return Optional.empty();
            }
        } catch (RuntimeException e) {
            // fail-close：Redis 不可用时拒绝放行
            log.error("预览票据单次校验失败（Redis 不可用，fail-close）: {}", e.getMessage());
            return Optional.empty();
        }
        redisUtils.expire(key, ttl.toSeconds(), TimeUnit.SECONDS);

        String fileName = claims.get(CLAIM_FILE_NAME, String.class);
        log.info("消费预览票据 space={} path={} file={}", spaceId, relPath, fileName);
        return Optional.of(new Ticket(UUID.fromString(spaceId), relPath,
                fileName == null ? "" : fileName));
    }

    /**
     * 已核销的票据载荷。
     *
     * @param spaceId      资料库空间 id
     * @param relativePath 空间内的相对路径
     * @param fileName     原始文件名（可能为空串）
     */
    public record Ticket(UUID spaceId, String relativePath, String fileName) {
    }
}
